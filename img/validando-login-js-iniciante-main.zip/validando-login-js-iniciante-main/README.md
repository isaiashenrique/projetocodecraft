<h2>Validando form de login com JS</h2>

<p>Codigo disponibilizado do tutorial lançado no youtube</p>
<p>Método simples voltado para iniciantes na linguagem</p>

<p>Clique e <a href="https://www.youtube.com/victorgemelgo" target="blank">Siga o canal do youtube</a>
