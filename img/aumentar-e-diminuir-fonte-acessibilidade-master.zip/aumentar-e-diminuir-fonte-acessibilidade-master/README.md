## Aumentar e diminuir fonte - Acessibilidade ##

Simples script JavaScript para aumentar e diminuir fonte.  
Esse simples recurso ajudará na acessibilidade da sua aplicação. Auxiliando pessoas com baixa visão ou dificuldade de leitura.